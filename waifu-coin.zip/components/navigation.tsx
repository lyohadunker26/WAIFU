"use client"

import * as React from "react"
import { useState } from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Menu } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"
import { useRouter } from 'next/navigation'

export function Navigation() {
  const router = useRouter()
  const [isOpen, setIsOpen] = useState(false)

  const scrollToSection = (sectionId: string) => {
    setIsOpen(false)
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-sm border-b border-pink-200">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="font-bold text-2xl text-pink-500">
          WAIFU CORPORATION
        </Link>
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" className="p-0 md:hidden" onClick={() => setIsOpen(!isOpen)}>
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent 
            side="right" 
            className="w-[300px] sm:w-[400px] bg-gradient-to-b from-white/80 to-transparent backdrop-blur-md border-l border-pink-200"
          >
            <nav className="flex flex-col space-y-4 mt-4">
              <Link 
                href="#home" 
                className="text-pink-600 hover:text-pink-500 transition-colors" 
                onClick={() => scrollToSection('home')}
              >
                Home
              </Link>
              <Link 
                href="#solana" 
                className="text-pink-600 hover:text-pink-500 transition-colors" 
                onClick={() => scrollToSection('solana')}
              >
                WAIFU COIN
              </Link>
              <Link 
                href="#nfts" 
                className="text-pink-600 hover:text-pink-500 transition-colors" 
                onClick={() => scrollToSection('nfts')}
              >
                NFTs
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <nav className="hidden md:flex space-x-6">
          <Link 
            href="#home" 
            className="text-pink-600 hover:text-pink-500 transition-colors" 
            onClick={() => scrollToSection('home')}
          >
            Home
          </Link>
          <Link 
            href="#solana" 
            className="text-pink-600 hover:text-pink-500 transition-colors" 
            onClick={() => scrollToSection('solana')}
          >
            WAIFU COIN
          </Link>
          <Link 
            href="#nfts" 
            className="text-pink-600 hover:text-pink-500 transition-colors" 
            onClick={() => scrollToSection('nfts')}
          >
            NFTs
          </Link>
        </nav>
      </div>
    </div>
  )
}

