import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

export default function TokenPage() {
  return (
    <div className="min-h-screen pt-24">
      <section className="container">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <h1 className="text-4xl font-bold mb-6">WAIFU COIN Token</h1>
            <p className="text-lg text-gray-600 mb-6">
              The native cryptocurrency of the waifu ecosystem, powered by Solana blockchain technology.
            </p>
            <div className="grid gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between">
                    <span className="font-medium">Total Supply</span>
                    <span>1,000,000,000 WAIFU</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between">
                    <span className="font-medium">Network</span>
                    <span>Solana</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between">
                    <span className="font-medium">Token Type</span>
                    <span>SPL</span>
                  </div>
                </CardContent>
              </Card>
            </div>
            <Button className="mt-6 bg-pink-500 hover:bg-pink-600">
              View on Solscan
            </Button>
          </div>
          <div className="flex-1">
            <Image
              src="/placeholder.svg"
              alt="Token Illustration"
              width={500}
              height={500}
              className="rounded-lg"
            />
          </div>
        </div>
      </section>
    </div>
  )
}

