import type { Metadata } from "next"
import { Inter } from 'next/font/google'
import "./globals.css"
import { Navigation } from "@/components/navigation"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "WAIFU COIN - Bringing Waifu Culture to Blockchain",
  description: "The first waifu-themed cryptocurrency on the Solana network",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-pink-50`}>
        <Navigation />
        <main>{children}</main>
      </body>
    </html>
  )
}

