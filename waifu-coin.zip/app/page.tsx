import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import { Instagram, Twitter, PinIcon as PinterestIcon, RssIcon as Reddit, Send } from 'lucide-react'
import { Navigation } from "@/components/navigation"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <section id="home" className="pt-20 pb-12">
        <div className="container-fluid px-0 md:container md:px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/A%20manga-style%20illustration%20of%20a%20seductive%20waifu%20with%20rosy%20cheeks%20and%20a%20playful,%20delighted%20expression,%20look...wer.%20%20She%20has%20long,%20straight%20light-colored%20hair%20in%20a%20voluminous%20style,%20a%20rounded%20chin,%20and%20a%20flirtatious%20pose.%20The%20backgro.jpg-6zT08utzHLHijBITJAd54UTutw73ns.jpeg"
                alt="Waifu Coin Mascot"
                width={1000}
                height={1000}
                className="w-full h-auto object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="w-full md:w-1/2 p-8 md:p-12 space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold text-pink-500 leading-tight">
                Bringing Waifu Culture to Blockchain
              </h1>
              <p className="text-xl text-gray-600">
                Join the kawaii revolution in crypto with WAIFU COIN - the first waifu-themed cryptocurrency on the Solana network.
              </p>
              <div className="flex gap-4">
                <Button size="lg" className="bg-pink-500 hover:bg-pink-600">
                  Buy WAIFU
                </Button>
                <Button size="lg" variant="outline" className="border-pink-500 text-pink-500 hover:bg-pink-50">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="solana" className="py-20 bg-white">
        <div className="container-fluid px-0 md:container md:px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 text-pink-500">
            WAIFU COIN on Solana Network
          </h2>
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 order-2 md:order-1">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Isekai%20anime%20art%20featuring%20a%20playful,%20manga-style%20waifu%20with%20long,%20blonde%20hair,%20a%20full%20hairstyle,%20and%20a%20wa...s%20facing%20forward,%20her%20mouth%20open,%20showing%20a%20teasing%20expression%20with%20red%20cheeks.%20%20The%20background%20is%20a%20solid%20pastel%20pink.%20He%20(5).jpg-BheV2nizi6q75N6R27XWCxJYVeoIUe.jpeg"
                alt="Solana Network Waifu"
                width={1000}
                height={1000}
                className="w-full h-auto object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="w-full md:w-1/2 p-8 md:p-12 space-y-6 order-1 md:order-2">
              <h3 className="text-2xl font-bold text-pink-500">Fast & Secure Transactions</h3>
              <p className="text-lg text-gray-600">
                Built on Solana's lightning-fast blockchain, WAIFU COIN offers instant transactions with minimal fees. Perfect for trading your favorite waifu NFTs and participating in the anime crypto ecosystem.
              </p>
              <Button className="bg-pink-500 hover:bg-pink-600">
                View on Solscan
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="nfts" className="py-20">
        <div className="container-fluid px-0 md:container md:px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 text-pink-500">
            Exclusive Waifu NFTs on OpenSea
          </h2>
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 p-8 md:p-12 space-y-6 order-2 md:order-1">
              <h3 className="text-2xl font-bold text-pink-500">Collect Unique Waifus</h3>
              <p className="text-lg text-gray-600">
                Own a piece of the waifu universe with our exclusive NFT collection. Each waifu is unique and comes with special benefits for WAIFU COIN holders.
              </p>
              <Button className="bg-pink-500 hover:bg-pink-600">
                Browse Collection
              </Button>
            </div>
            <div className="w-full md:w-1/2 order-1 md:order-2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2x3_________________________________%20(5)-myS2CU8avzy0EMlN2N3UHIWTdnJYAC.png"
                alt="NFT Collection Preview"
                width={1000}
                height={1000}
                className="w-full h-auto object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 text-pink-500">
            Why Choose WAIFU COIN?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-pink-50 border-pink-200">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2 text-pink-500">Community Driven</h3>
                <p className="text-gray-600">
                  Join a passionate community of waifu enthusiasts and crypto lovers.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-pink-50 border-pink-200">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2 text-pink-500">Solana Powered</h3>
                <p className="text-gray-600">
                  Enjoy fast transactions and low fees on the Solana network.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-pink-50 border-pink-200">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2 text-pink-500">Exclusive NFTs</h3>
                <p className="text-gray-600">
                  Access unique waifu NFTs and special holder benefits.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="py-8 border-t border-pink-200">
        <div className="container">
          <div className="flex flex-col items-center gap-4">
            <h3 className="text-2xl font-bold text-pink-500">Join us</h3>
            <div className="flex gap-6">
              <Link href="#" className="text-pink-500 hover:text-pink-600">
                <Instagram size={24} />
              </Link>
              <Link href="#" className="text-pink-500 hover:text-pink-600">
                <Twitter size={24} />
              </Link>
              <Link href="#" className="text-pink-500 hover:text-pink-600">
                <PinterestIcon size={24} />
              </Link>
              <Link href="#" className="text-pink-500 hover:text-pink-600">
                <Reddit size={24} />
              </Link>
              <Link href="#" className="text-pink-500 hover:text-pink-600">
                <Send size={24} />
              </Link>
            </div>
            <p className="text-gray-600 mt-4">© 2025 WAIFU CORPORATION. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

