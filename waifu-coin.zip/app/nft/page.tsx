import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import Image from "next/image"

export default function NFTPage() {
  return (
    <div className="min-h-screen pt-24">
      <section className="container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Waifu NFT Collection</h1>
          <p className="text-lg text-gray-600">
            Exclusive anime-style NFTs available on OpenSea
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Image
                  src="/placeholder.svg"
                  alt={`Waifu NFT ${i}`}
                  width={300}
                  height={300}
                  className="rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold mb-2">Waifu #{i}</h3>
                <p className="text-gray-600">
                  A unique collectible NFT from the WAIFU COIN collection.
                </p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-pink-500 hover:bg-pink-600">
                  View on OpenSea
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}

